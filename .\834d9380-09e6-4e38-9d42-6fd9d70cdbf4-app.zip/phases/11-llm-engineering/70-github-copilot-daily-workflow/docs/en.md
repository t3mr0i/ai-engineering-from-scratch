# GitHub Copilot for Software Engineers: The Daily Workflow (2026)

> By 2026 "Copilot" is no longer one feature. It is a ladder: ghost-text completion, Copilot Chat, edit-multiple-files, and an autonomous **agent mode** that plans, edits across the repo, runs the terminal, and opens a pull request. The same model surface also runs **server-side**: the Copilot coding agent picks up an assigned GitHub issue and produces a draft PR without a human at the keyboard. The skill that separates a 10x user from a frustrated one is no longer "write a good prompt" — it is knowing which rung of the ladder a given task belongs on, and how to keep the review loop tight enough that you stay accountable for code you did not type.

**Type:** Learn
**Languages:** Python (stdlib — task-to-mode router + acceptance simulator)
**Prerequisites:** Phase 11 · 01 (Prompt engineering), Phase 15 · 09 (Coding-agent landscape)
**Time:** ~50 minutes

## The Problem

Most teams adopt Copilot as autocomplete and stop there. They get a measurable but small lift on boilerplate and miss the part of the product that actually moves a sprint: agent mode, code review, and the server-side coding agent. The opposite failure is just as common — engineers hand a vague issue to agent mode, get a 400-line PR they don't understand, approve it under deadline pressure, and ship a subtle bug into production. Both failures come from the same root cause: **treating Copilot as a single tool instead of a capability ladder, each rung with a different blast radius and a different review obligation.**

The engineering question for 2026 is not "is Copilot good." It is operational: for *this* task, which surface do I invoke, what context do I have to feed it, and what is the verification step I will not skip before the diff lands?

## The Concept

### The capability ladder

| Surface | What it does | Latency / blast radius | You review |
|---|---|---|---|
| **Completion (ghost text)** | Inline suggestion as you type; single hunk | Instant; one edit site | The line you accept |
| **Copilot Chat** | Q&A over open file / selection / workspace | Seconds; read-only by default | The explanation, then you apply edits manually |
| **Edits (multi-file)** | Proposes a coordinated change set across files you pin | Seconds; the pinned set | The whole diff, file by file |
| **Agent mode (in-IDE)** | Plans, edits across the repo, runs terminal/tests, iterates on failures | Minutes; the working tree | The plan, the commands it ran, the final diff |
| **Coding agent (server-side)** | Assigned a GitHub issue → opens a draft PR autonomously | Background; a branch + PR | The PR as if a junior engineer wrote it |

The rule of thumb: **climb the ladder only as far as the task's ambiguity requires, and no further.** A one-line null-check is a completion, not an agent run. A "migrate this module to the new auth API across 9 files with tests" task is exactly what edits/agent mode exist for. Using agent mode for the null-check wastes minutes and produces a diff you have to read anyway; using completion for the migration produces nine disconnected edits that don't compose.

### Context is the product

Copilot's output quality is dominated by what it can see, not by prompt wording. The 2026 context surfaces, in rough order of leverage:

- **Open editors and the active selection** — the cheapest, highest-signal context. Curate your tabs before you ask.
- **`#`-references in Chat** — `#file`, `#selection`, `#codebase`, `#changes` (the working diff), `#terminalLastCommand`. Pulling the failing test output in with `#terminalLastCommand` is often the single highest-value move when debugging.
- **Custom instructions** — `.github/copilot-instructions.md` is read on every request in the repo. This is where "we use pytest, not unittest", "all new modules need a module docstring", and "never import from `legacy/`" live. It is the IDE-assistant analogue of an agent's `CLAUDE.md` / `AGENTS.md` (Phase 14 · 33).
- **MCP servers** — Copilot is an MCP client. Wiring a Jira or internal-docs MCP server into the IDE means agent mode can read a ticket or your service catalog without you pasting it. This is the same MCP you learned in Phase 13, now consumed by the assistant rather than authored by you.

A practical consequence: a repo with a good `copilot-instructions.md` and the right MCP servers gets *systematically* better output from the same model than a bare repo. The differentiator is repo hygiene, not prompt cleverness.

### Code review and the PR loop

Two distinct review directions, often confused:

1. **You review Copilot's code.** Every rung above completion produces a diff you are accountable for. The non-negotiable: read the diff and run the tests *before* you approve. Agent mode that ran `pytest` and reported green is necessary, not sufficient — it can also have weakened an assertion to make a test pass (the "reward-hacking" failure from Phase 14 · 38). Read what changed in the tests, not just whether they're green.
2. **Copilot reviews your code.** Copilot code review posts inline comments on a PR — yours or a teammate's. Treat it as a fast, tireless first-pass reviewer that catches the boring 70% (unhandled errors, missing null checks, obvious security smells) so human reviewers spend their attention on design. It is not a substitute for a human approver, and it has a false-positive rate; a human still owns the merge.

### Copilot vs Cursor vs Claude Code

Same job, three product philosophies — and a real engineer in 2026 often uses more than one:

- **GitHub Copilot** — deepest GitHub integration (issues → coding agent → PR → review, all in one platform), model choice across vendors, strongest fit when your work *is* the GitHub flow.
- **Cursor** — an editor built around the assistant rather than a plugin bolted onto one; strongest multi-file "composer" ergonomics and codebase-wide context indexing.
- **Claude Code** — terminal-native agent with explicit permission modes and routines (Phase 15 · 10); strongest when the work is long-horizon, unattended, or scripted into CI.

They converge on the same loop — plan, edit, run, verify — and increasingly share the same plumbing (MCP, the same frontier models). The choice is about *where you live*: the GitHub web UI, a bespoke editor, or the terminal. Lock-in is low; the transferable skill is the ladder and the review discipline, not the vendor.

### What stays your job

Copilot does not own: the decision of *what* to build, the architecture trade-off, the judgment that a green test suite actually covers the risk, and the accountability for the merge. Phase 15 · 09 showed that scaffolding now matters as much as the model. In the IDE *you* are part of the scaffold — the retrieval step (which tabs, which `#`-refs), the verifier (which tests you trust), and the kill switch (the approval you withhold).

## Use It

`code/main.py` is a deterministic, stdlib-only model of the two decisions this lesson is about:

1. A **task-to-mode router** that takes a short task description and routes it to the right rung of the ladder, with the reasoning shown.
2. An **acceptance simulator** that takes a proposed diff plus a test result and decides `MERGE` / `REQUEST CHANGES` / `BLOCK` — encoding the "green tests are necessary, not sufficient" rule (it blocks a diff whose only change to a test is a weakened assertion, even when tests pass).

No network and no real model — the point is to make the *decision policy* explicit and runnable, the same way Phase 15 · 10 made the permission classifier runnable.

## Ship It

`outputs/skill-copilot-task-router.md` is a one-page decision aid: paste a task, get the recommended Copilot surface, the context you should pin (`#`-refs, instructions file, MCP servers), and the verification gate to apply before the diff lands.

## Exercises

1. Run `code/main.py`. Which task in the sample set routes to agent mode, and which to plain completion? Change one task's description so it moves *up* one rung — what word triggered the change?

2. The acceptance simulator blocks one diff whose tests are green. Find it. Explain in one sentence why "tests pass" was the wrong signal, and which Phase 14 · 38 concept it maps to.

3. Write a `.github/copilot-instructions.md` (10 lines max) for a repo you actually work in. Include one "never do X" rule and one "always do Y" rule. Predict one concrete suggestion it would change.

4. Pick a real task from your backlog that you'd normally do by hand. Assign it to the server-side Copilot coding agent (or describe the issue you'd write). What three things must be in the issue body for the resulting PR to be reviewable?

5. You wire a Jira MCP server into your IDE so agent mode can read tickets directly. Name one task this makes dramatically faster — and one new risk it introduces (hint: the agent now reads attacker-controllable text; see Phase 18 · 15, indirect prompt injection).

## Key Terms

| Term | What people say | What it actually means |
|---|---|---|
| Ghost text | "Autocomplete" | Inline single-hunk completion as you type |
| Copilot Chat | "Ask the AI" | Read-default Q&A over selection/file/workspace via `#`-references |
| Agent mode | "Let it do the whole thing" | In-IDE loop: plan → multi-file edit → run terminal/tests → iterate |
| Coding agent | "Copilot opens PRs" | Server-side agent assigned a GitHub issue, produces a draft PR |
| `copilot-instructions.md` | "Config file" | Per-repo instructions read on every request — the IDE analogue of `CLAUDE.md` |
| `#`-reference | "Tagging context" | Explicit context handles (`#file`, `#codebase`, `#changes`, `#terminalLastCommand`) |
| Copilot code review | "AI reviewer" | Inline PR comments; a first-pass reviewer, not a merge owner |
| MCP client | "Plugins for the IDE" | Copilot consuming MCP servers (Jira, docs) as agent-mode context |

## Further Reading

- [GitHub Docs — Copilot agent mode](https://docs.github.com/en/copilot) — the in-IDE plan/edit/run loop and how to drive it.
- [GitHub Docs — Copilot coding agent](https://docs.github.com/en/copilot/using-github-copilot/coding-agent) — issue → draft PR, the server-side surface.
- [GitHub Docs — Repository custom instructions](https://docs.github.com/en/copilot/customizing-copilot) — `copilot-instructions.md` and prompt files.
- [GitHub Docs — Copilot code review](https://docs.github.com/en/copilot/using-github-copilot/code-review) — what the automated reviewer does and does not own.
- [GitHub Changelog](https://github.blog/changelog/label/copilot/) — the only reliable currency source; Copilot's surface changes monthly.

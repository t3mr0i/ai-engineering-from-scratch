# Analyzing Legacy Code with AI: The Refactoring Slice Framework (2026)

> In 2026, large language models can read a 10,000-line legacy module and produce a dependency graph, a risk-ranked change list, and a first draft of the replacement — inside a single context window. That capability is real and widely deployed, but it accounts for fewer than half of the teams that attempt AI-assisted modernization. The other half stall not because the model is wrong, but because the humans around it have no framework for deciding which slice to cut first, how large a slice to take, and what "done" means before the next slice starts. The failure is operational, not technical. This lesson establishes the slice-based analysis workflow that the rest of this course builds on: from the first LLM-generated code audit (this lesson) through safe refactor execution (Phase 14, Lessons 38–39) and production controls (Phase 17, Lessons 20 and 25).

**Type:** Learn
**Languages:** Python (stdlib — legacy code scorer + slice prioritizer)
**Prerequisites:** Phase 11 · 01 (Prompt engineering), Phase 14 · 38 (Verification gates)
**Time:** ~45 minutes

## The Problem

The standard AI modernization pitch is seductive: paste in the legacy module, ask the model to rewrite it, ship the result. In practice this fails in two predictable ways. First, the model's rewrite is structurally correct but semantically wrong — it passes the tests that exist, not the tests that *should* exist, because the legacy code's implicit contracts (undocumented edge cases, data shape assumptions, caller expectations) were never made explicit before the rewrite began. Second, even when the rewrite is sound, the resulting PR is 2,000 lines across 40 files with no clear review path, so it either sits unreviewed or gets rubber-stamped. In both cases the root cause is identical: the rewrite was treated as a single atomic operation rather than a sequenced series of bounded, verifiable slices.

The engineering question for a consulting team is not "can the model rewrite this?" It is: what are the correct slice boundaries, in what order do we cut them, and what is the verification gate each slice must pass before we cut the next? That is a design decision requiring human judgment. The model's job is to analyze the codebase and surface the information needed to make that decision well — coupling metrics, change-frequency data, test coverage gaps, security smells — not to make the decision itself.

## The Concept

### The four-pass audit protocol

Asking a model to "analyze this legacy code" produces a broad, generic list. Asking it to perform four focused passes, in sequence, produces actionable structure. The passes are:

| Pass | Prompt focus | Model output | Human decision |
|---|---|---|---|
| **1. Structure** | "Map the module's public API, internal dependencies, and all call sites in the repo" | Dependency graph; entry/exit points; dead code candidates | Which parts are truly encapsulated vs. entangled |
| **2. Risk** | "Identify security smells, hardcoded secrets, SQL/shell injection surfaces, and deprecated dependency versions" | Ordered risk list with evidence | Which risks are blockers vs. acceptable technical debt |
| **3. Coverage** | "Enumerate every code path. For each, state whether it has a test that exercises it, and what the input space is" | Coverage gap map | Which gaps must be closed before any refactoring begins |
| **4. Slice candidates** | "Given the structure, risk, and coverage map, propose 5–8 bounded slices ordered by: (a) highest risk, (b) lowest coupling, (c) has or can get tests" | Ranked slice list with rationale | Final slice order and go/no-go on each |

Each pass should reference the output of the previous one. Pass 4 without Pass 3 is the failure mode: you cannot confidently assert a slice is "done" if you do not know which paths were tested before and after.

### Scoring a legacy module before you slice it

Before any rewrite, assign each candidate module a readiness score. This is not about whether the code is bad — all legacy code is bad, that is why you are here. It is about whether you have enough information and test coverage to cut a safe slice.

| Dimension | Red (score 0) | Amber (score 1) | Green (score 2) |
|---|---|---|---|
| **Coupling** | Module has >5 callers in other bounded contexts | 2–5 callers, interfaces exist | Single owner, clear interface |
| **Test coverage** | <40% branch coverage; no integration test | 40–70%; some happy-path integration tests | >70%; integration test covers failure paths |
| **Secret/config hygiene** | Hardcoded secrets, env vars read mid-call | Config centralized but unvalidated | Config injected at boundary, validated at startup |
| **Dependency age** | Direct dependency with known CVE | No CVE but end-of-life | All dependencies on supported versions |
| **Change frequency** | >3 commits per week in past 6 months | 1–3 per week | Stable (<1 per week) or frozen |

A module scoring 0–4 needs stabilization work (tests, secret extraction) before it is a safe modernization target. A module scoring 5–7 can proceed with caution — explicitly close the amber gaps before cutting the slice. A module scoring 8–10 is the right place to start; early wins here build team confidence and prove the workflow before you tackle the harder cases.

This scoring approach is deliberately low-tech. The point is to make the readiness assessment explicit and auditable, not to automate it away.

### Slice sizing and the review obligation

A slice should be the largest change whose full diff a senior engineer can review in under 30 minutes and whose test delta is fully explainable. In practice this is usually one module boundary, one dependency upgrade, or one security pattern applied consistently — not all three. Phase 14 · 38 (Verification gates) operationalizes the review step; the constraint here is upstream: slices that exceed this bound should be split, not force-merged under deadline pressure.

The model is useful for sizing. Ask it: "If I cut this slice, how many lines change, how many call sites are affected, and what new tests are needed?" If any answer is "I'm not sure" or "it depends on callers I can't see," the slice is too large or the codebase context is incomplete.

### Using current models effectively

As of mid-2026, Claude Sonnet 4.x and Claude Opus 4.x offer 1M-token context windows. This covers even large legacy codebases in a single pass. Practical constraints:

- **Context construction matters more than model choice.** Feed the model the actual source files, not a prose description. Include the test files alongside the source. A 1M-token window filled with the right code typically yields materially better analysis than a 128k window filled with prose summaries — in our experience, the gap is large enough that swapping models is rarely worth the effort if the context is poor.
- **Use structured output for the audit.** Ask for JSON or a defined markdown table; free-form prose analysis is harder to feed into Phase 14 · 38's gate-check format.
- **Reproduce the audit before acting on it.** Run the same four-pass protocol twice (temperature 0) with the same files. If the slice candidates differ materially, the codebase is underspecified — fill the gaps before you cut.

Cross-link: the reviewer agent in Phase 14 · 39 can consume the structured slice proposal output from Pass 4 directly, using it as a task specification. Design the Pass 4 output format with that handoff in mind.

### What the model cannot substitute for

The four-pass protocol surfaces information; it does not replace the following human decisions:

1. **Business context.** The model does not know that Module X is the billing path and must be frozen until Q4.
2. **Organizational risk appetite.** Two teams with identical codebases can have legitimately different answers to "how large is a safe slice?"
3. **Domain contracts.** Undocumented business rules embedded in legacy code are the hardest extraction problem. The model can flag "this branch is taken only when the input is negative" but cannot tell you whether that branch represents intentional behavior or a latent bug — only a domain expert can.

The slice framework is a structured way to surface these decisions early, make them explicit, and record them so the reviewer agent in Phase 14 · 39 has the right context.

## Use It

`code/main.py` is a deterministic, stdlib-only model of the two core decisions in this lesson:

1. A **legacy module scorer** that evaluates a module description against the five readiness dimensions and returns a numeric score and a readiness tier (Red / Amber / Green).
2. A **slice prioritizer** that takes a list of candidate slices with their scores and orders them by: safety (no Red dimensions), then by a combined score of risk reduction and coupling, producing a recommended sequence with the rationale shown for each position.

No network, no real model — the point is to make the scoring and prioritization policy explicit and verifiable before you apply it to a real codebase.

## Ship It

`outputs/skill-legacy-refactor-slice-planner.md` is a one-page decision aid: the four-pass prompt templates, the readiness scoring rubric in table form, slice sizing rules of thumb, and the verification gate checklist that links each slice to Phase 14 · 38's gate format.

## Exercises

1. Run `code/main.py`. Which candidate slice is ranked first, and which dimension prevented a higher-scoring module from taking that slot? Change one dimension of the lower-scoring module to Green — does it move up in the ranking?

2. The prioritizer in `code/main.py` outputs a recommended sequence. Find the slice it ranks last. Write one sentence explaining why low ranking does not mean "skip it" — and when that slice should actually be cut first.

3. Apply Pass 1 of the four-pass audit protocol to a real module in a codebase you work with. Ask a model to map its public API, internal dependencies, and call sites. Compare its dependency graph to your mental model. Where did the model surface a coupling you had not noticed?

4. The readiness scoring table has five dimensions. Name one dimension that matters for your specific domain but is not on the list. Write the Red / Amber / Green criteria for it. How would you weight it relative to the existing five?

5. Design the handoff between the Pass 4 slice output from this lesson and the reviewer agent in Phase 14 · 39. What fields must the Pass 4 JSON contain so the reviewer can run its verification gates without additional context from you?

## Key Terms

| Term | What people say | What it actually means |
|---|---|---|
| Refactoring slice | "A chunk of the rewrite" | A bounded, independently deployable and verifiable unit of change with explicit entry/exit criteria |
| Four-pass audit | "Let the model analyze the code" | A structured sequence of focused prompts (structure, risk, coverage, slice candidates) designed to produce actionable output, not a single open-ended analysis |
| Readiness score | "Is this module safe to touch?" | A numeric rubric across five dimensions (coupling, coverage, secrets, dependency age, change frequency) used to sequence modernization work |
| Coupling | "How tangled is it?" | The number and nature of callers across bounded context boundaries; high coupling increases slice blast radius |
| Coverage gap map | "What's not tested?" | An enumeration of code paths without test coverage, produced in Pass 3; required before any slice can be declared safe to cut |
| Domain contract | "Hidden business logic" | Implicit behavioral requirements embedded in legacy code that no documentation describes; the primary source of silent regressions in rewrites |
| Verification gate | "Did this slice actually work?" | A pre-defined, automatable check (test suite, diff size bound, coverage delta) that a slice must pass before the next slice begins; operationalized in Phase 14 · 38 |
| Slice sizing | "How big should the PR be?" | The constraint that a slice's full diff must be reviewable by a senior engineer in under 30 minutes; anything larger should be split |

## Consultant field notes

These are the patterns a senior modernization consultant recognizes from the second meeting onward. Names matter because they compress a diagnosis the team would otherwise spend two weeks rediscovering.

1. **The demo-grade rewrite.** A model produces a clean refactor against a hand-picked sample of the legacy code; production reveals it never saw the ten callers that violated the implicit contract. The lesson is that the audit must run against the whole repository, not a representative module.

2. **The high-score module with a hidden Red dimension.** The prioritizer ranks a module Green across four dimensions; the fifth is a 0 nobody looked at. The lesson is that readiness scores are only as honest as the assessment behind each cell — never accept a Green row without inspecting its evidence.

3. **The slice that grew during review.** The PR opened at 400 lines; by the time three reviewers commented it was 1,800. The lesson is that a slice is sized at *cut* time, not at merge time — if review is finding scope to add, the boundary was wrong.

4. **The vendor pilot that never escaped the security review.** The modernization ran a successful PoC against synthetic data; the real-data path surfaced secrets, PII handling, and audit-logging gaps that had no slice boundary at all. The lesson is that readiness scoring must include a sixth dimension: data classification, not just code hygiene.

5. **The use case everyone approved but nobody wanted.** The business sponsor signed off, the architecture board signed off, and the resulting module shipped — and sat unused. The lesson is that slice selection should weight caller frequency and downstream user impact, not only risk reduction, or the team will produce correct code for a problem no one has.

## Further Reading

- [Martin Fowler — Refactoring (official site)](https://refactoring.com/) — the canonical reference on bounded change, test-first refactoring, and safe transformation patterns. The slice framework is an LLM-assisted implementation of these principles.
- [OWASP Top 10](https://owasp.org/www-project-top-ten/) — the risk pass in the four-pass audit should explicitly map findings to OWASP categories; this is the authoritative list.
- [Google Engineering Practices — Code Review guidelines](https://google.github.io/eng-practices/review/) — the review obligation that sizes slices; "reviewable in 30 minutes" is an operationalization of these guidelines.
- [Anthropic — Claude model documentation](https://docs.claude.com/en/docs/about-claude/models) — current model capabilities, context window sizes, and structured output support for the four-pass audit.
- [NIST SP 800-218 (Secure Software Development Framework)](https://csrc.nist.gov/publications/detail/sp/800-218/final) — the security-smells pass maps to SSDF practices PW.1 and PW.4; useful when the modernization scope includes a compliance mandate.
